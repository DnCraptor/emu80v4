﻿/*
 *  Emu80 v. 4.x
 *  © Viktor Pykhonin <pyk@mail.ru>, 2016-2018
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef ADDRSPACE_H
#define ADDRSPACE_H

#include "EmuObjects.h"

/*struct DeviceItem
{
    AddressableDevice* addrDevice; // ссылка на устройство
    int firstAddress;              // начальный адрес устройства
    int itemSize;                  // размер области устройства в байтах
    int devFirstAddr;              // смещение в области памяти устройства
};*/

class AddrSpace : public AddressableDevice
{
    public:
        AddrSpace(uint8_t nullByte = 0xFF);
        uint8_t readByte(int addr) override;
        void writeByte(int addr, uint8_t value) override;

        void addRange(int firstAddr, int lastAddr, AddressableDevice* addrDevice, int devFirstAddr = 0);
        virtual void addReadRange(int firstAddr, int lastAddr, AddressableDevice* addrDevice, int devFirstAddr = 0);
        virtual void addWriteRange(int firstAddr, int lastAddr, AddressableDevice* addrDevice, int devFirstAddr = 0);

private:
        static constexpr int MAX_RANGES = 4;

        uint8_t m_nullByte;          // байт, считываемый из нераспределенного пространства

        int m_itemCountR = 0;
        AddressableDevice* m_devicesR[MAX_RANGES] = {};
        int m_firstAddressesR[MAX_RANGES] = {};
        int m_itemSizesR[MAX_RANGES] = {};
        int m_devFirstAddressesR[MAX_RANGES] = {};

        int m_itemCountW = 0;
        AddressableDevice* m_devicesW[MAX_RANGES] = {};
        int m_firstAddressesW[MAX_RANGES] = {};
        int m_itemSizesW[MAX_RANGES] = {};
        int m_devFirstAddressesW[MAX_RANGES] = {};
};


class AddrSpaceMapper : public AddressableDevice
{
    public:
        explicit AddrSpaceMapper(int nPages);
        void reset() override {m_curPage = 0;}

        void attachPage(int page, AddressableDevice* as);
        void setCurPage(int page);

        void writeByte(int addr, uint8_t value) override;
        uint8_t readByte(int addr) override;

protected:
        static constexpr int MAX_PAGES = 2;

        AddressableDevice* m_pages[MAX_PAGES] = {};
        int m_nPages;
        int m_curPage = 0;
};


class AddrSpaceShifter : public AddressableDevice
{
    public:
        AddrSpaceShifter(AddressableDevice* as, int shift);

        void writeByte(int addr, uint8_t value) override;
        uint8_t readByte(int addr) override;

private:
        AddressableDevice* m_as;
        int m_shift;
};


class AddrSpaceInverter : public AddressableDevice
{
    public:
        AddrSpaceInverter(AddressableDevice* as);

        void writeByte(int addr, uint8_t value) override;
        uint8_t readByte(int addr) override;

private:
        AddressableDevice* m_as;
};


class AddrSpaceWriteSplitter : public AddressableDevice
{
    public:
        AddrSpaceWriteSplitter(AddressableDevice* as1, AddressableDevice* as2) : m_as1(as1), m_as2(as2) {}

        void writeByte(int addr, uint8_t value) override;
        uint8_t readByte(int addr) override;

private:
        AddressableDevice* m_as1;
        AddressableDevice* m_as2;
};


#endif // ADDRSPACE_H
