﻿/*
 *  Emu80 v. 4.x
 *  © Viktor Pykhonin <pyk@mail.ru>, 2016-2018
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MEM_H
#define MEM_H

#include <string>

#include "EmuObjects.h"

class SRam : public AddressableDevice
{
    public:
        SRam(unsigned memSize);
        virtual ~SRam();
        void writeByte(int addr, uint8_t value) override;
        uint8_t readByte(int addr) override;
        int getSize() { return m_size; }

    private:
        int m_size;
        size_t m_offset;
};

class Ram : public AddressableDevice
{
    public:
        //Ram();
        Ram(unsigned memSize);
        Ram(uint8_t* buf, unsigned memSize);
        //Ram(int memSize, std::string fileName);
        virtual ~Ram();
        void writeByte(int addr, uint8_t value) override;
        uint8_t readByte(int addr) override;
        /*const*/ uint8_t* getDataPtr() {return m_buf ? m_buf : m_extBuf;}
        uint8_t& operator[](int nAddr) {return m_buf[nAddr];} // no check for borders, use with caution
        int getSize() {return m_size;}
        void setTag(int tag) {m_tag = tag;}

    protected:

    private:
        int m_size;
        uint8_t* m_buf = nullptr;
        uint8_t* m_extBuf = nullptr;
};



class Rom : public AddressableDevice
{
    public:
       /// Rom();
        Rom(unsigned memSize, std::string fileName);
        Rom(const uint8_t* data, unsigned memSize);
        virtual ~Rom();
        void writeByte(int, uint8_t)  override {}
        uint8_t readByte(int addr) override;
        int getSize() {return m_size;}
        virtual const uint8_t* getDataPtr() {return m_buf;}
        virtual const uint8_t& operator[](int nAddr) {return m_buf[nAddr];} // no check for borders, use with caution

    protected:
        int m_size;
        const uint8_t* m_buf = nullptr;
        bool b_ram = false;
};



class NullSpace : public AddressableDevice
{
    public:
        NullSpace(uint8_t nullByte = 0xFF) {m_nullByte = nullByte;}
        void writeByte(int, uint8_t)  override {}
        uint8_t readByte(int)  override {return m_nullByte;}

    protected:

    private:
        uint8_t m_nullByte = 0xFF;
};


#endif // MEM_H
