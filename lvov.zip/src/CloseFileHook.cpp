﻿/*
 *  Emu80 v. 4.x
 *  © Viktor Pykhonin <pyk@mail.ru>, 2016-2022
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "Globals.h"
#include "CloseFileHook.h"
#include "Emulation.h"
#include "TapeRedirector.h"

void CloseFileHook::addTapeRedirector(TapeRedirector* fr)
{
    if (!fr || m_nFr >= MAX_REDIRECTORS)
        return;

    for (int i = 0; i < m_nFr; ++i)
        if (m_frs[i] == fr)
            return;

    m_frs[m_nFr++] = fr;
}


bool CloseFileHook::hookProc()
{
    if (!m_isEnabled || (m_hasSignature && !checkSignature()))
        return false;

    for (int i=0; i<m_nFr; i++)
        m_frs[i]->closeFile();

    return false;
}


ElapsedTimer::ElapsedTimer()
{
    pause();
}

void ElapsedTimer::start(unsigned ms)
{
    uint64_t curTime = g_emulation->getCurClock();
    m_curClock = curTime + ms * g_emulation->getFrequency() / 1000;
    resume();
}


void ElapsedTimer::stop()
{
    pause();
}


void ElapsedTimer::operate()
{
    pause();
    onElapse();
}


CloseFileTimer::CloseFileTimer(TapeRedirector* tr)
{
    m_tr = tr;
}


void CloseFileTimer::onElapse()
{
    m_tr->closeFile();
}
